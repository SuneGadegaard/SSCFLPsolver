These instances can be found at 
http://www-eio.upc.es/~elena/sscplp/index.html