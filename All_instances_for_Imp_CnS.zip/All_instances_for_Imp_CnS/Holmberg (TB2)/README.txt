These instances can be found at
http://www.kajh.se/vineopt/problemdata/cloc/index.html